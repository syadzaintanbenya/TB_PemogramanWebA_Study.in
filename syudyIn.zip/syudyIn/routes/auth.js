var express = require('express');
var router = express.Router();
var mysql = require('mysql2');
var User = require('../models/users');

router.post('/login', async function (req, res, next) {
    const user = req.body.username;
    const find = await User.findOne({
      where: { username: user },
    });
    console.log(finds.password);
    if (find == null)
      return res.json({ message: 'Anda belum terdaftar, silahkan register!' });

    const pass = req.body.password;
    if (find.password != pass)
      return res.status(400).json({ message: 'Password Salah' });
    return res.status(200).json({ message: 'Anda berhasil login' });
});

module.exports = router;
