var express = require('express');
var router = express.Router();
var mysql = require('mysql2');
var User = require('../models/users');

/* GET users listing. */
router.get('/', async function (req, res, next) {
  const users = await User.findAll();
  res.json(users);
});

/*ADD users*/
router.post('/resgister', async function (req, res, next) {
  try {
    const user = await User.create({
      user_id: req.body.username,
      email: req.body.email,
      username: req.body.username,
      password: req.body.password,
      active: 1,
      avatar: 'picture',
    });

    if (user) {
      let response = {
        message: 'Register Berhasil',
      };
      return res.json(response);
    } else {
      res.json({ message: 'Register Gagal, silahkan ulangi!' });
    }
  } catch (error) {
    console.log(error);
  }
});

router.post('/login', async function (req, res, next) {
  const user = req.body.username;
  const find = await User.findOne({
    where: { username: user },
  });
  console.log(find.password);

  if (find == null)
    return res.json({ message: 'Anda belum terdaftar, silahkan register!' });

  const pass = req.body.password;
  if (find.password != pass)
    return res.status(400).json({ message: 'Password Salah' });

  return res.status(200).json({ message: 'Anda berhasil login' });
});

// /*EDIT users*/
// router.post('/:id/edit', function (req, res, next) {
//   const connection = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'studyin',
//   });
//   connection.connect();

//   let id = req.params.id;

//   let first_name = req.body.first_name;
//   let last_name = req.body.last_name;
//   let email = req.body.email;
//   let username = req.body.username;
//   let password = req.body.password;

//   let sql =
//     'UPDATE users SET first_name=?,last_name=?,email=?,username=?,password=? WHERE id = ?';
//   connection.query(
//     sql,
//     [first_name, last_name, email, username, password, id],
//     (err, rows, fiels) => {
//       if (err) throw err;

//       let response = {
//         message: 'Data user berhasil diubah',
//         affectedRows: rows.affectedRows,
//       };
//       res.json(response);
//     }
//   );

//   connection.end();
// });

// /*DELETE users*/
// router.post('/:id/delete', function (req, res, next) {
//   const connection = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'studyin',
//   });
//   connection.connect();

//   let id = req.params.id;

//   let sql = 'DELETE FROM users WHERE id = ?';
//   connection.query(sql, [id], (err, rows, fiels) => {
//     if (err) throw err;

//     let response = {
//       message: 'Data user berhasil dihapus',
//       affectedRows: rows.affectedRows,
//     };
//     res.json(response);
//   });

//   connection.end();
// });

module.exports = router;
